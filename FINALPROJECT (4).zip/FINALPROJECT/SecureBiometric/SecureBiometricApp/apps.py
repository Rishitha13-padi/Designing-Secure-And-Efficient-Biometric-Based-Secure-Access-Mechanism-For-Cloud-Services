from django.apps import AppConfig


class SecurebiometricappConfig(AppConfig):
    name = 'SecureBiometricApp'
